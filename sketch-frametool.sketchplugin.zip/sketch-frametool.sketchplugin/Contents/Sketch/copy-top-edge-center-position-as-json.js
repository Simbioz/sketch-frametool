var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/commands/copy-top-edge-center-position-as-json.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/commands/copy-top-edge-center-position-as-json.js":
/*!***************************************************************!*\
  !*** ./src/commands/copy-top-edge-center-position-as-json.js ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _helpers_layers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../helpers/layers */ "./src/helpers/layers.js");
/* harmony import */ var _helpers_messages__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../helpers/messages */ "./src/helpers/messages.js");
/* harmony import */ var _helpers_clipboard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../helpers/clipboard */ "./src/helpers/clipboard.js");
/* harmony import */ var _helpers_frames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../helpers/frames */ "./src/helpers/frames.js");




/* harmony default export */ __webpack_exports__["default"] = (function (context) {
  var layer = Object(_helpers_layers__WEBPACK_IMPORTED_MODULE_0__["getFirstSelectedLayer"])(context);
  if (!layer) return;
  var normalizedFrame = Object(_helpers_frames__WEBPACK_IMPORTED_MODULE_3__["getNormalizedFrame"])(context, layer);
  var point = {
    x: normalizedFrame.x + normalizedFrame.width / 2.0,
    y: normalizedFrame.y
  };
  Object(_helpers_clipboard__WEBPACK_IMPORTED_MODULE_2__["copyStringToClipboard"])("{\"x\": ".concat(point.x, ", \"y\": ").concat(point.y, "}"));
  Object(_helpers_messages__WEBPACK_IMPORTED_MODULE_1__["showCopiedToClipboardMessage"])(context, "Left edge center position");
});

/***/ }),

/***/ "./src/helpers/clipboard.js":
/*!**********************************!*\
  !*** ./src/helpers/clipboard.js ***!
  \**********************************/
/*! exports provided: copyStringToClipboard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "copyStringToClipboard", function() { return copyStringToClipboard; });
/* global NSPasteboard, NSPasteboardTypeString */
function copyStringToClipboard(string) {
  var pasteboard = NSPasteboard.generalPasteboard();
  pasteboard.declareTypes_owner([NSPasteboardTypeString], null);
  pasteboard.setString_forType(string, NSPasteboardTypeString);
}

/***/ }),

/***/ "./src/helpers/frames.js":
/*!*******************************!*\
  !*** ./src/helpers/frames.js ***!
  \*******************************/
/*! exports provided: getNormalizedFrame */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getNormalizedFrame", function() { return getNormalizedFrame; });
/* harmony import */ var _layers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./layers */ "./src/helpers/layers.js");

function getNormalizedFrame(context, layer) {
  var framingRootLayer = Object(_layers__WEBPACK_IMPORTED_MODULE_0__["getClosestFramingRootAncestor"])(context, layer);
  if (!framingRootLayer) return;
  var layerFrame = layer.frame.changeBasis({
    from: layer.parent,
    to: framingRootLayer
  });
  return {
    x: layerFrame.x / framingRootLayer.frame.width,
    y: layerFrame.y / framingRootLayer.frame.height,
    width: layerFrame.width / framingRootLayer.frame.width,
    height: layerFrame.height / framingRootLayer.frame.height
  };
}

/***/ }),

/***/ "./src/helpers/layers.js":
/*!*******************************!*\
  !*** ./src/helpers/layers.js ***!
  \*******************************/
/*! exports provided: getFirstSelectedLayer, getClosestFramingRootAncestor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFirstSelectedLayer", function() { return getFirstSelectedLayer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getClosestFramingRootAncestor", function() { return getClosestFramingRootAncestor; });
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);

function getFirstSelectedLayer(context) {
  var selectedLayers = context.selection;

  if (selectedLayers.length === 0) {
    context.document.showMessage("⚠️ Select a layer first!");
    return;
  }

  return sketch__WEBPACK_IMPORTED_MODULE_0___default.a.fromNative(selectedLayers[0]);
}
function getClosestFramingRootAncestor(context, layer) {
  var parent = layer.parent;

  if (!parent) {
    // Reached document root without finding anything
    context.document.showMessage("\u26A0\uFE0F Must have a parent whose name contains \"[framing-root]\"!");
    return null;
  }

  if ((parent.name || "").includes("[framing-root]")) return parent;
  return getClosestFramingRootAncestor(context, parent);
}

/***/ }),

/***/ "./src/helpers/messages.js":
/*!*********************************!*\
  !*** ./src/helpers/messages.js ***!
  \*********************************/
/*! exports provided: showCopiedToClipboardMessage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "showCopiedToClipboardMessage", function() { return showCopiedToClipboardMessage; });
function showCopiedToClipboardMessage(context, name) {
  return context.document.showMessage("".concat(name, " copied to clipboard! \uD83C\uDF89"));
}

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ })

/******/ });
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=copy-top-edge-center-position-as-json.js.map